#version 130

#define FSH
#define NETHER

#include "/programs/gbuffers_hand.glsl"