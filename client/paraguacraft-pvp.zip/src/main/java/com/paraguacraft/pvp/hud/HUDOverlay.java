package com.paraguacraft.pvp.hud;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.item.ItemStack;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Mouse;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

public class HUDOverlay {

    private final Minecraft mc = Minecraft.getMinecraft();
    
    private final int colorParagua = new Color(0, 85, 255).getRGB();
    private final int colorBlanco = new Color(255, 255, 255).getRGB();
    private final int colorBgNormal = new Color(10, 10, 10, 120).getRGB(); 
    private final int colorBgPressed = new Color(0, 85, 255, 160).getRGB(); 
    
    private List<Long> leftClicks = new ArrayList<Long>();
    private boolean wasLeftMouseDown = false;

    @SubscribeEvent
    public void onRender(RenderGameOverlayEvent.Text event) {
        if (mc.gameSettings.showDebugInfo || mc.thePlayer == null) {
            return;
        }

        FontRenderer fr = mc.fontRendererObj;
        int x = 5;
        int y = 5;

        // 1. Módulos de Texto
        fr.drawStringWithShadow("FPS: \u00A7f" + Minecraft.getDebugFPS(), x, y, colorParagua);
        y += 10;

        int ping = 0;
        if (mc.getNetHandler() != null) {
            NetworkPlayerInfo playerInfo = mc.getNetHandler().getPlayerInfo(mc.thePlayer.getUniqueID());
            if (playerInfo != null) ping = playerInfo.getResponseTime();
        }
        fr.drawStringWithShadow("Ping: \u00A7f" + (ping < 0 ? 0 : ping) + " ms", x, y, colorParagua);
        y += 10;

        calculateCPS();
        fr.drawStringWithShadow("CPS: \u00A7f" + leftClicks.size(), x, y, colorParagua);

        // 2. Keystrokes
        drawKeystrokes(x, y + 20);
        
        // 3. NUEVO: Armor Status
        drawArmorStatus();
    }

    private void calculateCPS() {
        boolean isLeftDown = Mouse.isButtonDown(0);
        if (isLeftDown && !wasLeftMouseDown) leftClicks.add(System.currentTimeMillis());
        wasLeftMouseDown = isLeftDown;
        long currentTime = System.currentTimeMillis();
        leftClicks.removeIf(time -> currentTime - time > 1000);
    }

    private void drawKeystrokes(int startX, int startY) {
        drawKey(startX + 22, startY, 20, 20, "W", mc.gameSettings.keyBindForward.isKeyDown());
        drawKey(startX, startY + 22, 20, 20, "A", mc.gameSettings.keyBindLeft.isKeyDown());
        drawKey(startX + 22, startY + 22, 20, 20, "S", mc.gameSettings.keyBindBack.isKeyDown());
        drawKey(startX + 44, startY + 22, 20, 20, "D", mc.gameSettings.keyBindRight.isKeyDown());
        drawKey(startX, startY + 44, 31, 20, "LMB", Mouse.isButtonDown(0));
        drawKey(startX + 33, startY + 44, 31, 20, "RMB", Mouse.isButtonDown(1));
    }

    private void drawKey(int x, int y, int width, int height, String text, boolean isPressed) {
        Gui.drawRect(x, y, x + width, y + height, isPressed ? colorBgPressed : colorBgNormal);
        int textWidth = mc.fontRendererObj.getStringWidth(text);
        mc.fontRendererObj.drawStringWithShadow(text, x + (width - textWidth) / 2, y + (height - 8) / 2, colorBlanco);
    }

    // Lógica pura de renderizado de ítems
    private void drawArmorStatus() {
        ScaledResolution sr = new ScaledResolution(mc);
        int x = sr.getScaledWidth() - 25; 
        int y = sr.getScaledHeight() - 25; // Empezamos desde abajo a la derecha

        // Activar las luces Vanilla para que los ítems en 3D no se vean negros
        RenderHelper.enableGUIStandardItemLighting();

        // Armadura (0 = botas, 1 = pantalones, 2 = pechera, 3 = casco)
        for (int i = 0; i < 4; i++) {
            ItemStack stack = mc.thePlayer.inventory.armorItemInSlot(i);
            if (stack != null) {
                mc.getRenderItem().renderItemAndEffectIntoGUI(stack, x, y);
                mc.getRenderItem().renderItemOverlays(mc.fontRendererObj, stack, x, y);
                y -= 20; // Subimos 20 píxeles por cada pieza
            }
        }

        // Item en la mano (Espada, manzanas, bloques)
        ItemStack held = mc.thePlayer.getHeldItem();
        if (held != null) {
            y -= 5; // Un pequeño espacio para separarlo de la armadura
            mc.getRenderItem().renderItemAndEffectIntoGUI(held, x, y);
            mc.getRenderItem().renderItemOverlays(mc.fontRendererObj, held, x, y);
        }

        RenderHelper.disableStandardItemLighting();
    }
}