package com.paraguacraft.pvp.modules;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.util.ChatComponentText;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent.KeyInputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.ClientTickEvent;
import org.lwjgl.input.Keyboard;

public class QoLManager {

    private final Minecraft mc = Minecraft.getMinecraft();
    
    public static boolean toggleSprintActive = true; 
    public static boolean fullbrightActive = true; 

    private KeyBinding toggleSprintKey;
    private KeyBinding fullbrightKey;

    public QoLManager() {
        // Registramos las teclas en el menú de controles de Minecraft
        toggleSprintKey = new KeyBinding("Toggle Sprint", Keyboard.KEY_V, "Paraguacraft PvP");
        fullbrightKey = new KeyBinding("Fullbright", Keyboard.KEY_G, "Paraguacraft PvP");
        
        ClientRegistry.registerKeyBinding(toggleSprintKey);
        ClientRegistry.registerKeyBinding(fullbrightKey);
    }

    // Leemos el teclado para activar/desactivar los módulos
    @SubscribeEvent
    public void onKeyInput(KeyInputEvent event) {
        if (toggleSprintKey.isPressed()) {
            toggleSprintActive = !toggleSprintActive;
            sendMessage("Toggle Sprint: " + (toggleSprintActive ? "\u00A7aON" : "\u00A7cOFF"));
        }
        
        if (fullbrightKey.isPressed()) {
            fullbrightActive = !fullbrightActive;
            if (!fullbrightActive) {
                mc.gameSettings.gammaSetting = 1.0F; // Volver a brillo normal
            }
            sendMessage("Fullbright: " + (fullbrightActive ? "\u00A7aON" : "\u00A7cOFF"));
        }
    }

    // Lógica ejecutada en cada frame (sin lag)
    @SubscribeEvent
    public void onClientTick(ClientTickEvent event) {
        if (mc.thePlayer == null) return;

        // Lógica del Toggle Sprint: Fuerza el botón de sprint a estar "presionado" si no hay menús abiertos
        if (toggleSprintActive && mc.currentScreen == null) {
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindSprint.getKeyCode(), true);
        }

        // Lógica del Fullbright: Congela el Gamma al 1000%
        if (fullbrightActive && mc.gameSettings.gammaSetting < 100.0F) {
            mc.gameSettings.gammaSetting = 100.0F;
        }
    }

    // Método rápido para imprimir mensajes en el chat local del cliente
    private void sendMessage(String msg) {
        if (mc.thePlayer != null) {
            mc.thePlayer.addChatMessage(new ChatComponentText("\u00A78[\u00A79Paraguacraft\u00A78] \u00A77" + msg));
        }
    }
}