package com.paraguacraft.pvp.gui;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiSelectWorld;
import net.minecraft.client.renderer.GlStateManager;

import java.awt.Color;
import java.io.IOException;

public class CustomMainMenu extends GuiScreen {

    @Override
    public void initGui() {
        int centerX = this.width / 2;
        int centerY = this.height / 2;
        
        // ID, x, y, width, height, text
        this.buttonList.add(new GuiButton(0, centerX - 100, centerY - 20, 200, 20, "Singleplayer"));
        this.buttonList.add(new GuiButton(1, centerX - 100, centerY + 5, 200, 20, "Multiplayer"));
        this.buttonList.add(new GuiButton(2, centerX - 100, centerY + 30, 98, 20, "Settings"));
        this.buttonList.add(new GuiButton(3, centerX + 2, centerY + 30, 98, 20, "Quit"));
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        // Fondo Negro absoluto
        drawRect(0, 0, this.width, this.height, new Color(10, 10, 10).getRGB());
        
        // Franja Azul decorativa superior (Color Paraguacraft)
        drawRect(0, 0, this.width, 4, new Color(0, 85, 255).getRGB());

        GlStateManager.pushMatrix();
        GlStateManager.scale(3.0F, 3.0F, 1.0F);
        // Título centrado. Math para escalar correctamente el texto.
        this.drawCenteredString(this.fontRendererObj, "Paraguacraft PvP", this.width / 6, (this.height / 2) / 3 - 25, new Color(0, 85, 255).getRGB());
        GlStateManager.popMatrix();

        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    protected void actionPerformed(GuiButton button) throws IOException {
        switch (button.id) {
            case 0:
                this.mc.displayGuiScreen(new GuiSelectWorld(this));
                break;
            case 1:
                this.mc.displayGuiScreen(new GuiMultiplayer(this));
                break;
            case 2:
                this.mc.displayGuiScreen(new GuiOptions(this, this.mc.gameSettings));
                break;
            case 3:
                this.mc.shutdown();
                break;
        }
    }
}